package com.tns.collegeservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CollegeserviceKamal1Application {

	public static void main(String[] args) {
		SpringApplication.run(CollegeserviceKamal1Application.class, args);
	}

}
